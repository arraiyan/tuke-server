def body_edit():
    data = None
    dummy="<html><html></html></html><div><div><div>hi there <a>hi</a>"
    count = 0
                

    return dummy
print(body_edit())